import { Component, inject, input } from '@angular/core';
import { ContactsService } from '../../services/contacts-services';
import { Contact } from '../../interfaces/contact';
import { RouterModule } from '@angular/router';


@Component({
  selector: 'app-contact-details-page',
  imports: [RouterModule],
  templateUrl: './contact-details-page.html',
  styleUrl: './contact-details-page.scss'
})
export class ContactDetailsPage {
  idContacto = input.required<string>();
  contacto: Contact | undefined;
  contactService= inject(ContactsService)

  async ngOnInit (){
    this.contacto = await this.contactService.getContactById(this.idContacto()!)
  }

  async toggleFavorite(){
    if(this.contacto){
      const res = await this.contactService.setFavourite(this.contacto.id);
      this.contacto.isFavourite = !this.contacto.isFavourite;
    }
  }


  }
