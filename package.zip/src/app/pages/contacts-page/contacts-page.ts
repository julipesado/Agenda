import { Component, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ContactListItem } from '../../components/contact-list-item/contact-list-item';
import { Contact, NewContact } from '../../interfaces/contact';
import { AuthService } from '../../services/auth.service';
import { ContactsService } from '../../services/contacts-services';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contacts-page',
  imports: [RouterModule, ContactListItem, FormsModule, CommonModule],
  templateUrl: './contacts-page.html',
  styleUrl: './contacts-page.scss'
})
export class ContactsPage {

  authService= inject(AuthService);
  contactsService=inject(ContactsService);
c: any;

createContact(form: any) {
const nuevoContacto: NewContact={
  firstName:form.firstName,
  lastName:form.lastName,
  adress: form.adress,
  email: form.email,
  image: form.image,
  number: form.number,
  company: form.company,
  isFavourite: form.isFavourite

}

this.contactsService.createContact(nuevoContacto)
}

  

}


