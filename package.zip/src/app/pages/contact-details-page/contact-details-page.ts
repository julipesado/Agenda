import { Component } from '@angular/core';
import { ContactListItem } from "../../components/contact-list-item/contact-list-item";
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-contact-details-page',
  imports: [],
  templateUrl: './contact-details-page.html',
  styleUrl:'./contact-details-page.scss'
})
export class ContactDetailsPage{
  
}
