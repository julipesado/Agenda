import { Injectable } from '@angular/core';
import { Contact, NewContact } from '../interfaces/contact';
import id from '@angular/common/locales/id';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  aleatorio = Math.random()

  contacts: Contact[] = [
    {
      id: "1",
      firstName: "Julia",
      lastName: "Pesado",
      number: "3413492841",
      email: "juliapesadoc@gmail.com",
      image: "",
      company: "",
      adress: "Funes",
      isFavourite: true
    },
    {
      id: "2",
      firstName: "Ramiro",
      lastName: "Coletto",
      number: "3415061199",
      email: "rcoletto23@gmail.com",
      image: "",
      company: "",
      adress: "Rosario",
      isFavourite: false
    }
  ]
  contactsService: any;

  getContacts() { }
  getContactById() {

  }
  createContact(nuevoContacto: NewContact) {

    const contacto: Contact = {
      ...nuevoContacto,
      id: Math.random().toString()
    }
    this.contactsService.push(nuevoContacto)
  }

  editContact() { };
  deleteContact(id: string) {
    this.contacts = this.contacts.filter((contact: { id: any; }) => contact.id !== id)
  }
  setFavourite() { }


}
